
        // write(f , msg , sizeof(msg));